package simulation.components.light;

public enum TrafficDirection {
	WEST_EAST, EAST_WEST, NORTH_SOUTH, SOUTH_NORTH, FOUR_WAY;
}
