package simulation.components.light;

public interface LightState {
	public void next();
	//public void setState(LightState state);
}
