package simulation.components.light;

public enum TrafficPattern {
	SIMPLE, ALTERNATING
}
