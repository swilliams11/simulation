package simulation.agent;

public interface Agent {
  public void run();
}
